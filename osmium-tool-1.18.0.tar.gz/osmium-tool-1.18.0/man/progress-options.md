
\--progress
:   Show progress bar. Usually a progress bar is only displayed if STDOUT
    and STDERR are detected to be TTY. With this option a progress bar is
    always shown. Note that a progress bar will never be shown when reading
    from STDIN or a pipe.

\--no-progress
:   Do not show progress bar. Usually a progress bar is displayed if STDOUT
    and STDERR are detected to be a TTY. With this option the progress bar is
    suppressed. Note that a progress bar will never be shown when reading
    from STDIN or a pipe.

