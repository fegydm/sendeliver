#define CATCH_CONFIG_MAIN
#include "catch.hpp" // IWYU pragma: keep
